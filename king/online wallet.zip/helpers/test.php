<?php

require __DIR__."/resolver.php";

$config = resolve();